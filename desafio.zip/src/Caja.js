function Caja(props) {
return (
    <div className="Caja">
    <p> 
        Aromatizando Ambientes {props.nombres}
    </p>
    </div>
);
}

export default Caja;