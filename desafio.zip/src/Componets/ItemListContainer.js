import './ItemListContainer.css';

function ItemListContainer (props) {
return (
    <div classname= 'Catalogo'>
        <h4>{props.greeting}</h4>
    </div>  
);
}

export default ItemListContainer;