import './Body.css';
import Card from './Card';

function Body () {
return (
    <section classname= 'cuerpo'>
        <Card/>
        <Card/>
        <Card/>
        <Card/>
    </section>
);
}
export default Body;