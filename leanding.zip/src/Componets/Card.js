import './Card.css';

function Card () {
return (
    <div classname= 'card'>
        <h4>Producto</h4>
        <h4>Descripcion</h4>
        <h4>Precio</h4>
        <h4>Contenido neto</h4>
    </div>
);
}
export default Card;